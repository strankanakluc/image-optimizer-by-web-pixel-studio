=== Image Optimizer by Web Pixel Studio ===
Contributors: duddi  
Tags: images, optimization, webp, compression, resize
Requires at least: 5.0
Tested up to: 6.9
Stable tag: 1.0.0
License: GPL-2.0+
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Optimizes images on upload. Define max. size and select the types of images to convert to webp and what quality the optimized image should have.

== Description ==

Image Optimizer by Web Pixel Studio optimizes images when uploading. Define the maximum image size and choose which file types should be converted to webp and what the compression or quality of the optimized image should be.

= Features =
* Retain or delete original images after optimization
* Set image quality and WebP compression method
* Convert specific image types to WebP
* Automatically set image alt text based on filename
* Define maximum width for uploaded images
* Bulk image optimization

= Settings =
* Go to Settings -> Image Optimizer by Web Pixel Studio in your WordPress dashboard. Here you can set the image quality, WebP compression method, and other options.

== Changelog ==

= 1.0.0 =
* Initial release
* Modern admin interface with gradient design
* Image optimization and WebP conversion
* Support for JPEG, PNG, GIF, BMP, TIFF, HEIC, and HEIF formats
* Bulk image optimization
* Automatic alt text generation
* Customizable image quality and compression settings


